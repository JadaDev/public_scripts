-- Create a stored procedure
DELIMITER //

CREATE PROCEDURE IncrementPlayerXP()
BEGIN
    SET @startLevel := 80;
    SET @endLevel := 255;
    SET @currentLevel := @startLevel;
    SET @previousXP := (SELECT Experience FROM world.player_xp_for_level WHERE Level = @currentLevel - 1);
    
    WHILE @currentLevel <= @endLevel DO
        SET @currentXP := @previousXP * 1.01;
        
        -- Insert the new level and experience into the table
        INSERT INTO world.player_xp_for_level (Level, Experience)
        VALUES (@currentLevel, @currentXP);
        
        SET @currentLevel := @currentLevel + 1;
        SET @previousXP := @currentXP;
    END WHILE;
    
    -- Display a success message
    SELECT CONCAT('Levels ', @startLevel, ' to ', @endLevel, ' have been incremented successfully.') AS Message;
END //

DELIMITER ;

-- Call the stored procedure to perform the increments
CALL IncrementPlayerXP();
